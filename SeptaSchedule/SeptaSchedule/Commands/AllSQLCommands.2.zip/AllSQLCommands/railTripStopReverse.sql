



SELECT
  (:end_stop_id) newStartId,


  (:start_stop_id) newEndId;
